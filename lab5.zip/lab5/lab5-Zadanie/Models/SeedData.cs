﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace lab5_Zadanie.Models
{
    public class SeedData
    {
        public static void Initialize(IServiceProvider serviceProvider)
        {
            using (var context = new MoviesContext(
                serviceProvider.GetRequiredService<
                    DbContextOptions<MoviesContext>>()))
            {
                if (context.MoviesItems.Any())
                {
                    return;   
                }
                context.MoviesItems.AddRange(
                    new MoviesItem
                    {
                        Id = 1,
                        Title = "Zielona mila",
                        ReleaseDate = "1999",
                        NumberOfReviews = 234,
                        RuntimeInMinutes = 130
                    },
                    new MoviesItem
                    {
                        Id = 2,
                        Title = "Skazani na Shawshank",
                        ReleaseDate = "1994",
                        NumberOfReviews = 214,
                        RuntimeInMinutes = 230
                    },
                    new MoviesItem
                    {
                        Id = 3,
                        Title = "Forrest Gump",
                        ReleaseDate = "1994",
                        NumberOfReviews = 190,
                        RuntimeInMinutes = 155
                    },
                    new MoviesItem
                    {
                        Id = 4,
                        Title = "Matrix",
                        ReleaseDate = "1999",
                        NumberOfReviews = 134,
                        RuntimeInMinutes = 180
                    }
                );
                context.SaveChanges();
            }
        }
    }
}
