using System;

namespace lab5_Zadanie
{
    public class Movies
    {
        public int Id { get; set; }
        public string ReleaseDate { get; set; }

        public int NumberOfReviews { get; set; }

        public int RuntimeInMinutes { get; set; }

        public string Title { get; set; }
    }
}
